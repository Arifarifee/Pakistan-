from streamlink.webbrowser.cdp.client import CDPClient, CDPClientSession
from streamlink.webbrowser.cdp.connection import CDPConnection, CDPSession
from streamlink.webbrowser.cdp.exceptions import CDPError
