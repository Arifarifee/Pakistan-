from streamlink.compat import deprecated


deprecated({
    "HTTPSession": ("streamlink.session.http.HTTPSession", None, None),
})
