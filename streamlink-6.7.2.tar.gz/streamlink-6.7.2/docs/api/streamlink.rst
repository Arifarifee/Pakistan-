Streamlink
----------

.. autofunction:: streamlink.streams
